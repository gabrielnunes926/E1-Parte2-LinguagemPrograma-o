
package Exercicio3Lampedusa;

import java.io.FileWriter;
import java.io.IOException;

public class Rio {
    String coloraçao;
    float densidade;
    String comprimentoMetros;

    public Rio(String coloraçao, float densidade, String comprimentoMetros) {
        this.coloraçao = coloraçao;
        this.densidade = densidade;
        this.comprimentoMetros = comprimentoMetros;
    }
    
    
    
    public String getFraseMolhar(){
        return "Se nao tomar cuidado, voce pode ser molhado pelo rio";
    }

    public String getColoraçao() {
        return coloraçao;
    }

    public float getDensidade() {
        return densidade;
    }

    public String getComprimentoMetros() {
        return comprimentoMetros;
    }
    
    
    
       public void salvarCSV(String caminhoArquivo) {
    try (FileWriter writer = new FileWriter(caminhoArquivo, true)) {
        writer.write(coloraçao + "," + densidade + "," + comprimentoMetros + ",\"" + getFraseMolhar() + "\"\n");
    } catch (IOException e) {
        e.printStackTrace();
    }
     }
}
