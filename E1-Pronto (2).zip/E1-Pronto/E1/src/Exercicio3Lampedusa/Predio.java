
package Exercicio3Lampedusa;

import java.io.FileWriter;
import java.io.IOException;

public class Predio {
    int alturaMetros;
    int larguraMetros;
    String cor;

    public Predio(int alturaMetros, int larguraMetros, String cor) {
        this.alturaMetros = alturaMetros;
        this.larguraMetros = larguraMetros;
        this.cor = cor;
    }
    
    
    public String getFraseAbrigar(){
        return "Esse predio pode abrigar muitas pessoas";
    }

    public int getAlturaMetros() {
        return alturaMetros;
    }

    public int getLarguraMetros() {
        return larguraMetros;
    }

    public String getCor() {
        return cor;
    }
    
    
    
     public void salvarCSV(String caminhoArquivo) {
    try (FileWriter writer = new FileWriter(caminhoArquivo, true)) {
        writer.write(alturaMetros + "," + larguraMetros + "," + cor + ",\"" + getFraseAbrigar() + "\"\n");
    } catch (IOException e) {
        e.printStackTrace();
    }
     }
}
