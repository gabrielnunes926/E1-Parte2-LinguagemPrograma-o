
package Exercicio3Lampedusa;

import java.io.FileWriter;
import java.io.IOException;

public class Barco {
    String material;
    String cor;
    String tamanho;

    public Barco(String material, String cor, String tamanho) {
        this.material = material;
        this.cor = cor;
        this.tamanho = tamanho;
    }
    
    
    public String getFraseFlutuar(){
        return "A maior funçao do barco eh flutuar";
    }

    public String getMaterial() {
        return material;
    }

    public String getCor() {
        return cor;
    }

    public String getTamanho() {
        return tamanho;
    }
    
    
    
     public void salvarCSV(String caminhoArquivo) {
    try (FileWriter writer = new FileWriter(caminhoArquivo, true)) {
        writer.write(material + "," + cor + "," + tamanho + ",\"" + getFraseFlutuar() + "\"\n");
    } catch (IOException e) {
        e.printStackTrace();
    }
     }
}
