
package Exercicio5;

import java.io.FileWriter;
import java.io.IOException;

public class Barbaro {
    String corCabelo;
    String arma;
    String acessorio;

    public Barbaro(String corCabelo, String arma, String acessorio) {
        this.corCabelo = corCabelo;
        this.arma = arma;
        this.acessorio = acessorio;
    }
    
    
    
    public String getFraseAtacar(){
        return "O barbaro foi ao ataque";
    }
    
    public String getFraseGritar(){
        return "O barbaro ataca gritando";
    }
    
    public String getFraseBabar(){
        return "O barbaro esta babando";
    }

    public String getCorCabelo() {
        return corCabelo;
    }

    public String getArma() {
        return arma;
    }

    public String getAcessorio() {
        return acessorio;
    }
    
    
    
  public void salvarCSV(String caminhoArquivo) {
    try (FileWriter writer = new FileWriter(caminhoArquivo, true)) {           
       writer.write(corCabelo + "," + arma + "," + acessorio+ ",\"" + getFraseAtacar() + ",\"" + getFraseGritar() + ",\"" + getFraseBabar() + "\"\n" );
    } catch (IOException e) {
        e.printStackTrace();
    }
    }
}
