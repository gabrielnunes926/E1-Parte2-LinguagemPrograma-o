
package Exercicio5;

import java.io.FileWriter;
import java.io.IOException;

public class Corredor {
    String arma;
    String montaria;
    String cabelo;

    public Corredor(String arma, String montaria, String cabelo) {
        this.arma = arma;
        this.montaria = montaria;
        this.cabelo = cabelo;
    }
    
    
    
    public String getFraseCavalgar(){
        return "Ele esta cavalgando";
    }
    
    public String getFraseCorrer(){
        return "O corredor esta correndo";
    }
    
    public String getFraseAssustar(){
        return "Em cima do porco, ele assusta muita gente";
    }

    public String getArma() {
        return arma;
    }

    public String getMontaria() {
        return montaria;
    }

    public String getCabelo() {
        return cabelo;
    }
    
    
    
    public void salvarCSV(String caminhoArquivo) {
    try (FileWriter writer = new FileWriter(caminhoArquivo, true)) {           
       writer.write(montaria + "," + arma + "," + cabelo+ ",\"" + getFraseCavalgar() + ",\"" + getFraseCorrer() + ",\"" + getFraseAssustar() + "\"\n" );
    } catch (IOException e) {
        e.printStackTrace();
    }
    }
}
