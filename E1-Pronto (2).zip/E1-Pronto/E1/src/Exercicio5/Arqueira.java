
package Exercicio5;

import java.io.FileWriter;
import java.io.IOException;

public class Arqueira {
    String corCabelo;
    String arma;
    int qntFlechas;
    
    

    public Arqueira(String corCabelo, String arma, int qntFlechas) {
        this.corCabelo = corCabelo;
        this.arma = arma;
        this.qntFlechas = qntFlechas;
    }
    
    
    
    public String getFraseCorrer(){
        return "A arqueira esta correndo";
    }
    
    public String getFraseAtirar(){
        return "A arqueira esta atirando flechas";
    }
    
    public String getFraseMirar(){
        return "A arqueira esta mirando";
    }

    public String getCorCabelo() {
        return corCabelo;
    }

    public String getArma() {
        return arma;
    }

    public int getQntFlechas() {
        return qntFlechas;
    }
    
    
    
    
    public void salvarCSV(String caminhoArquivo) {
    try (FileWriter writer = new FileWriter(caminhoArquivo, true)) {           
       writer.write(corCabelo + "," + arma + "," + qntFlechas+ ",\"" + getFraseCorrer() + ",\"" + getFraseAtirar() + ",\"" + getFraseMirar() + "\"\n" );
    } catch (IOException e) {
        e.printStackTrace();
    }
    }
}
