
package Exercicio4;

import java.io.FileWriter;
import java.io.IOException;

public class Cachorro {
    String raça;
    String cor;
    double peso;

    public Cachorro(String raça, String cor, double peso) {
        this.raça = raça;
        this.cor = cor;
        this.peso = peso;
    }
    
    
    
    public String getFraseLatir(){
        return "O cachorro esta latindo";
    }
    
    public String getFraseDormir(){
        return "O cachorro esta dormindo";
    }
    
    public String getFraseCorrer(){
        return "O cachorro esta correndo";
    }

    public String getRaça() {
        return raça;
    }

    public String getCor() {
        return cor;
    }

    public double getPeso() {
        return peso;
    }

    
     
     public void salvarCSV(String caminhoArquivo) {
    try (FileWriter writer = new FileWriter(caminhoArquivo, true)) {           
       writer.write(raça + "," + cor + "," + peso + ",\"" + getFraseLatir() + ",\"" + getFraseDormir() + ",\"" + getFraseCorrer() + "\"\n" );
    } catch (IOException e) {
        e.printStackTrace();
    }
     }
}
