
package Exercicio4;

import java.io.FileWriter;
import java.io.IOException;

public class Homem {
    String corCamisa;
    double altura;
    String corCalça;

    public Homem(String corCamisa, double altura, String corCalça) {
        this.corCamisa = corCamisa;
        this.altura = altura;
        this.corCalça = corCalça;
    }
    
    
    
    public String getFrasePintar(){
        return "O homem esta pintando";
    }
    
    public String getFraseColorir(){
        return "O homem esta colorindo";
    }
    
    public String getFraseAgir(){
        return "O homem esta se movendo";
    }

    public String getCorCamisa() {
        return corCamisa;
    }

    public double getAltura() {
        return altura;
    }

    public String getCorCalça() {
        return corCalça;
    }
    
    
    
    public void salvarCSV(String caminhoArquivo) {
    try (FileWriter writer = new FileWriter(caminhoArquivo, true)) {           
       writer.write(corCamisa + "," + altura + "," + corCalça + ",\"" + getFrasePintar() + ",\"" + getFraseColorir() + ",\"" + getFraseAgir() + "\"\n" );
    } catch (IOException e) {
        e.printStackTrace();
    }
    }
}
