
package Exercicio4;

import java.io.FileWriter;
import java.io.IOException;

public class Celular {
    String marca;
    String sistemaOperacional;
    int qntApp;

    public Celular(String marca, String sistemaOperacional, int qntApp) {
        this.marca = marca;
        this.sistemaOperacional = sistemaOperacional;
        this.qntApp = qntApp;
    }
    
    
    
    public String getFraseEnviar(){
        return "Mensagem enviada";
    }
    
    public String getFraseExcluir(){
        return "Mensagem apagada";
    }
    
    public String getFraseDesligar(){
        return "Celular desligado";
    }

    public String getMarca() {
        return marca;
    }

    public String getSistemaOperacional() {
        return sistemaOperacional;
    }

    public int getQntApp() {
        return qntApp;
    }
    
    
    
     public void salvarCSV(String caminhoArquivo) {
    try (FileWriter writer = new FileWriter(caminhoArquivo, true)) {           
       writer.write(marca + "," + sistemaOperacional + "," + qntApp + ",\"" + getFraseEnviar() + ",\"" + getFraseExcluir() + ",\"" + getFraseDesligar() + "\"\n" );
    } catch (IOException e) {
        e.printStackTrace();
    }
    }
}
