
package Exercicio2;

import java.io.FileWriter;
import java.io.IOException;

public class Moto {
    String cor;
    String marca;
    int peso;

    public Moto(String cor, String marca, int peso) {
        this.cor = cor;
        this.marca = marca;
        this.peso = peso;
    }    
    
   
    public String getFraseCorrer(){
        return "Kawasaki corre muito rapido";  
    }

    public String getCor() {
        return cor;
    }

    public String getMarca() {
        return marca;
    }

    public int getPeso() {
        return peso;
    }
    
    
    
   public void salvarCSV(String caminhoArquivo) {
    try (FileWriter writer = new FileWriter(caminhoArquivo, true)) {
        writer.write(cor + "," + marca + "," + peso + ",\"" + getFraseCorrer() + "\"\n");
    } catch (IOException e) {
        e.printStackTrace();
    }
    }
     
}
