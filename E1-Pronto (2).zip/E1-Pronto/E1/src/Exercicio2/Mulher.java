package Exercicio2;

import java.io.FileWriter;
import java.io.IOException;

public class Mulher {
    String nome;
    int telefone;
    String endereço;

    public Mulher(String nome, int telefone, String endereço) {
        this.nome = nome;
        this.telefone = telefone;
        this.endereço = endereço;
    }
    
    
    
    public String getFraseFalar(){
        return "Ah, vamo na sua";
    }

    public String getNome() {
        return nome;
    }

    public int getTelefone() {
        return telefone;
    }

    public String getEndereço() {
        return endereço;
    }
    
    
    
     public void salvarCSV(String caminhoArquivo) {
    try (FileWriter writer = new FileWriter(caminhoArquivo, true)) {
        writer.write(nome + "," + telefone + "," + endereço + ",\"" + getFraseFalar() + "\"\n");
    } catch (IOException e) {
        e.printStackTrace();
    }
     }
}
