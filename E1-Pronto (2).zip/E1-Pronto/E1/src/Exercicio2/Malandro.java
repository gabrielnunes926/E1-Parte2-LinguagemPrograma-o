package Exercicio2;

import java.io.FileWriter;
import java.io.IOException;

public class Malandro {
    private String estilo;
    private String penteado;
    private String joias;

   public Malandro(String estilo, String penteado, String joias){
        this.estilo = estilo;
        this.penteado = penteado;
        this.joias = joias;
    }
    
    public String getFraseViajar() {
    return "Ele gosta de viver e viajar, sem medo de morrer sem medo de arriscar";
}


    public String getEstilo() {
        return estilo;
    }

    public String getPenteado() {
        return penteado;
    }

    public String getJoias() {
        return joias;
    }

    public void viajar() {
        System.out.println("Ele gosta de viver e viajar, sem medo de morrer sem medo de arriscar");
    }

    public void salvarCSV(String caminhoArquivo) {
    try (FileWriter writer = new FileWriter(caminhoArquivo, true)) {
        writer.write(estilo + "," + penteado + "," + joias + ",\"" + getFraseViajar() + "\"\n");
    } catch (IOException e) {
        e.printStackTrace();
    }
}

}
