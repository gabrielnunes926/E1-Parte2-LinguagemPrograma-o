
package Exercicio3TorreEifel;

import java.io.FileWriter;
import java.io.IOException;

public class Ceu {
    String estaçaoAno;
    String Coloraçao;
    int qntNuvens;

    public Ceu(String estaçaoAno, String Coloraçao, int qntNuvens) {
        this.estaçaoAno = estaçaoAno;
        this.Coloraçao = Coloraçao;
        this.qntNuvens = qntNuvens;
    }
    
    
    
    public String getFraseChover(){
        return "Quando o ceu esta fechado, eh sinal de que vai chover";
    }

    public String getEstaçaoAno() {
        return estaçaoAno;
    }

    public String getColoraçao() {
        return Coloraçao;
    }

    public int getQntNuvens() {
        return qntNuvens;
    }
    
    
    
     public void salvarCSV(String caminhoArquivo) {
    try (FileWriter writer = new FileWriter(caminhoArquivo, true)) {
        writer.write(estaçaoAno + "," + Coloraçao + "," + qntNuvens + ",\"" + getFraseChover() + "\"\n");
    } catch (IOException e) {
        e.printStackTrace();
    }
     }
}
