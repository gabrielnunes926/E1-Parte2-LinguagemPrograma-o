
package Exercicio3TorreEifel;

import java.io.FileWriter;
import java.io.IOException;

public class Vegetaçao {
    String especie;
    int qntArvore;
    int qntanimais;

    public Vegetaçao(String especie, int qntArvore, int qntanimais) {
        this.especie = especie;
        this.qntArvore = qntArvore;
        this.qntanimais = qntanimais;
    }
    
    
    
    public String getFraseNascer(){
        return "Existe muita vegetaçao na imagem";
    }

    public String getEspecie() {
        return especie;
    }

    public int getQntArvore() {
        return qntArvore;
    }

    public int getQntanimais() {
        return qntanimais;
    }
    
    
    
   public void salvarCSV(String caminhoArquivo) {
    try (FileWriter writer = new FileWriter(caminhoArquivo, true)) {
        writer.write(especie + "," + qntArvore + "," + qntanimais + ",\"" + getFraseNascer() + "\"\n");
    } catch (IOException e) {
        e.printStackTrace();
    }
     }
}
