
package Exercicio3TorreEifel;

import java.io.FileWriter;
import java.io.IOException;

public class Torre {
    String material;
    int comprimentoMetros;
    int pesoKg;

    public Torre(String material, int comprimentoMetros, int pesoKg) {
        this.material = material;
        this.comprimentoMetros = comprimentoMetros;
        this.pesoKg = pesoKg;
    }
    
    
    
    public String getFraseSinalizar(){
        return "Com essa torre as pessoas podem se localizar";
    }

    public String getMaterial() {
        return material;
    }

    public int getComprimentoMetros() {
        return comprimentoMetros;
    }

    public int getPesoKg() {
        return pesoKg;
    }
    
    
    
     public void salvarCSV(String caminhoArquivo) {
    try (FileWriter writer = new FileWriter(caminhoArquivo, true)) {
        writer.write(material + "," + comprimentoMetros + "," + pesoKg + ",\"" + getFraseSinalizar() + "\"\n");
    } catch (IOException e) {
        e.printStackTrace();
    }
     }
}
